function viewById(data1)
	{
		$.ajax({
			type : "GET",
			url :"http://localhost:8888/jobDesc/getJobRequestList/"+data1 ,
			success: function(result){
				console.log(result.data.jobDescId);
					$("#jobDescId").append(result.data.jobDescId)
					$("#makerId").append(result.data.jobDescMakerId)
					$("#checkerId").append(result.data.jobDescCheckerId)
					$("#raisedonDate").append(result.data.jobDescRaisedOnDate)
					$("#approveRejectDate").append(result.data.jobDescApprovedRejectDate)
					$("#experience").append(result.data.jobDescExperience)
					$("#skill_mand").append(result.data.jobDescSkillsSetMandatory)
					$("#skill_opt").append(result.data.jobDescSkillsSetOptional)
					$("#profile").append(result.data.jobDescProfile)
					$("#qualification").append(result.data.jobDesQualification)
					$("#expected_doj").append(result.data.jobDescExpectedDateOfJoining)
					$("#no_of_candidates").append(result.data.jobDescNumberOfCandidates)
					$("#certification").append(result.data.jobDescCertification)
					$("#responsibility").append(result.data.jobDescResponsibility)
					$("#project").append(result.data.jobDescProject)


	}
});
		
//	}
//function approve(data1)
//{
//	 var jobDesc={
//	 jobDesc.jobDescNumberOfCandidates=${};  
//	 jobDesc.jobDescBudget; 
//	 }
//	$.ajax({
//		type : "PUT",
//		url :"http://localhost:8888/jobDesc/updateJobRequestStatus/"+data1 ,
//		success: function(result){
//			console.log(result.data.jobDescId);
//				}
//});
//	
//}
//function reject(data1)
//{
//	
//	$.ajax({
//		type : "PUT",
//		url :"http://localhost:8888/jobDesc/updateJobRequestStatus/"+data1 ,
//		success: function(result){
//			console.log(result.data.jobDescId);
//				}
//});
//	
}



$( document ).ready(function() {
	ajaxGet();
	
	// DO GET
	function ajaxGet(){
		$.ajax({
			type : "GET",
			url :"http://localhost:8888/jobDesc/getJobRequestList",
			success: function(result){
				if(result.errorMessage == "success"){
						$.each(result.data, function(index, data){
							var jobdesc = '<tr>' +
												'<td>' + result.data[index].jobDescId +  '</td>' +
												'<td>' + result.data[index].jobDescMakerId +  '</td>' +
												'<td>' + result.data[index].jobDescProfile + '</td>' +
												'<td>' + result.data[index].jobDescRaisedOnDate +  '</td>' +
												'<td>' + result.data[index].jobDescExpectedDateOfJoining +  '</td>' +
												' <td> <a href="#" style="color: #2196F3;" title="approve" data-toggle="tooltip" onclick=approve('+result.data[index].jobDescId+')><i class="material-icons">&#xE8DC;</i></a>'+
												' <a href="#" style="color: #F44336;" title="reject" data-toggle="tooltip" onclick=reject('+result.data[index].jobDescId+') ><i class="material-icons" >&#xE8DB;</i></a></td>'+
												'<td><a href="#" style="color: #2196F3;" title="View" data-toggle="modal" data-target="#myModal" onclick=viewBy('+result.data[index].jobDescId+') ><i class="material-icons">&#xE417;</i></a></td>'           
												 					+ '</tr>';
						  $('#example tbody').append(jobdesc)
						});
				}else{
					$("#getResultDiv").html("<strong>Error</strong>");
				}
			},
			error : function(e) {
				$("#getResultDiv").html("<strong>Error</strong>");
				console.log("ERROR: ", e);
			}
		});	
	}
})