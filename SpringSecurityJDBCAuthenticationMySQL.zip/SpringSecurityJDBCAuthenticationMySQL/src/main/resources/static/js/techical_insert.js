function onFormSubmit() 
{
	console.log("hiiiii");
	ajaxPost();
}

function ajaxPost()
{
	console.log("hiiiii ajaxPost");

	// PREPARE FORM DATA
	var col1 = 
	{
			techCandiadateId : $("#applid").val(),
			techInterviewerId :  $("#intrId").val(),
			techModeOfInterview :  $("#moi").val(),
			techDesignSkill :  $("#DESIGN_SKILL1").val(),
			techCodingSkill :  $("#CODING_SKILL1").val(),
			tech_TroubleShootingSkill :  $("#TROUBLE_SHOOTING_SKILL1").val(),
			techCommSkill :  $("#COMM_SKILL1").val(),
			techDbSkill :  $("#DB_SKILL1").val(),
			techTeamHandling :  $("#TEAM_HANDLING1").val(),
			techFunctionExposure :  $("#FUNCTION_EXPOSURE1").val(),
			techRoundNumber : 1,
			techFinalEvaluation :  $("#FINAL_EVALUATION1").val(),
	}
console.log(col1);
	var col2 = 
	{
			techCandiadateId : $("#applid").val(),
			techInterviewerId :  $("#intrId").val(),
			techModeOfInterview :  $("#moi").val(),
			techDesignSkill :  $("#DESIGN_SKILL2").val(),
			techCodingSkill :  $("#CODING_SKILL2").val(),
			tech_TroubleShootingSkill :  $("#TROUBLE_SHOOTING_SKILL2").val(),
			techCommSkill :  $("#COMM_SKILL2").val(),
			techDbSkill :  $("#DB_SKILL2").val(),
			techTeamHandling :  $("#TEAM_HANDLING2").val(),
			techFunctionExposure :  $("#FUNCTION_EXPOSURE2").val(),
			techRoundNumber : 2,
			techFinalEvaluation :  $("#FINAL_EVALUATION2").val(),
	}
	var col3 = 
	{
			techCandiadateId : $("#applid").val(),
			techInterviewerId :  $("#intrId").val(),
			techModeOfInterview :  $("#moi").val(),
			techDesignSkill :  $("#DESIGN_SKILL3").val(),
			techCodingSkill :  $("#CODING_SKILL3").val(),
			tech_TroubleShootingSkill :  $("#TROUBLE_SHOOTING_SKILL3").val(),
			techCommSkill :  $("#COMM_SKILL3").val(),
			techDbSkill :  $("#DB_SKILL3").val(),
			techTeamHandling :  $("#TEAM_HANDLING3").val(),
			techFunctionExposure :  $("#FUNCTION_EXPOSURE3").val(),
			techRoundNumber : 3,
			techFinalEvaluation :  $("#FINAL_EVALUATION3").val(),
	}
    var status ={
			techCandiadateId : $("#applid").val(),
			techEvalStatus : $("#status").val(),
			techEvalComments :	$("#comment").val(),
	}
	ajaxInsert(col1);
	ajaxInsert(col2);
	ajaxInsert(col3);
    ajaxInsertStatus(status);

	function ajaxInsert(obj)
	{		console.log("hiiiii ajaxInsert");

	$.ajax({
		type : "POST",
		contentType : "application/json",		
		url :"TechEvaluation/insert",
		data : JSON.stringify(obj),
		dataType : 'json',
		success : function(result){
			console.log("successfully");
		}
	})

	}
	
	function ajaxInsertStatus(objStatus)
	{		console.log("hiiiii statusInsert");

	$.ajax({
		type : "POST",
		contentType : "application/json",
		url :"TechEvaluation/insertStatus",
		data : JSON.stringify(objStatus),
		dataType : 'json',
		success : function(result){
			console.log("successfully");
		}
	})

	}
	/*function ajaxInsert(col2)
		{
			$.ajax({
				type : "POST",
				contentType : "application/json",
				url : window.location + "TechEvaluation/insert",
				data : JSON.stringify(col2),
				dataType : 'json'
					success : function(result)
			})

		}
		function ajaxInsert(col3)
		{
			$.ajax({
				type : "POST",
				contentType : "application/json",
				url : window.location + "TechEvaluation/insert",
				data : JSON.stringify(col3),
				dataType : 'json'
					success : function(result)
			})

		}*/




}





