
function viewById(data2)
{
	alert(data2)
	console.log("in template");
	$.ajax({
		type : "GET",
		url :"http://localhost:8888/TechEvaluation/candidateById/"+data2 ,
		success: function(result)
		{
			console.log(result.obj.cadidateID);
			console.log(result.obj.cadidateName);
			$("#candidateId").html(result.obj.cadidateID)
		    $("#candidateName").html(result.obj.cadidateName)
		    $("#jobRole").html(result.obj.appliedFor)
			$("#canndidEmail").html(result.obj.candidateEmailID)
			$("#contactNum").html(result.obj.candidateContactNO)
			$("#canndidjobId").html(result.obj.cadidateJdID)
			$("#expCTC").html(result.obj.candidateExpectedCTC)
			$("#currentCTC").html(result.obj.candidateCurrentCTC)
			$("#doa").html(result.obj.candidateDateoFApplication)
			$("#Amode").html(result.obj.candidateModeoFApplication)
			$("#Ccompany").html(result.obj.candidateCurrentComponyName)
			$("#exp").html(result.obj.candidateSinceWorkingDate)
			$("#qualification").html(result.obj.candidateLastQualDegree)
			$("#score").html(result.obj.candidateLastQualScore)
			$("#passYear").html(result.obj.candidateLastQualPassingYR)
			$("#certification").html(result.obj.candidateExtraCertification)
			$("#appliedBefore").html(result.obj.candidateAppliedBefore)
		}
		});
	
}


$( document ).ready(function() {
	ajaxGet();
	
	// DO GET
	function ajaxGet(){
		$.ajax({
			type : "GET",
			url :"http://localhost:8888/TechEvaluation/getCandidates",
			success: function(result){
				console.log("sucessful")
				if(result.errorMessage == "success"){
					console.log("sucessfulllll")
						$.each(result.obj, function(index, obj){
							console.log("IN FOR EACH")
							var jobdesc = '<tr>' +
												'<td>' + result.obj[index].cadidateID +  '</td>' +
												'<td>' + result.obj[index].appliedFor +  '</td>' +
												'<td>' + result.obj[index].candidateEmailID + '</td>' +
												'<td>' + result.obj[index].cadidateName +  '</td>' +
												'<td>' + result.obj[index].candidateLastQualDegree+'</td>' +
												'<td><a href="technical_evaluation_form.html" class="btn btn-primary btn-sm active" role="button" onclick=getcandidId('+result.obj[index].cadidateID+') >EVALUATION FORM</a></td>'+
												'<td><a href="#" style="color: #2196F3;" title="View" data-toggle="modal" data-target="#myModal1" onclick=viewById('+result.obj[index].cadidateID+')><i class="material-icons">&#xE417;</i></a></td>'           
												 					+ '</tr>';
						  $('#example tbody').append(jobdesc)
						});
				}else{
					$("#getResultDiv").html("<strong>Error</strong>");
				}
			},
			error : function(e) {
				$("#getResultDiv").html("<strong>Error</strong>");
				console.log("ERROR: ", e);
			}
		});		
	}
})
function getcandidId(data1)
{
			console.log("in dada1")
			sessionStorage.setItem("id",data1);
			var a=sessionStorage.getItem("id");
			
			
			
}


