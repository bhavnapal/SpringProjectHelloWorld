
function hrViewById(data2)
{
	alert(data2)
	console.log("in template");
	$.ajax({
		type : "GET",
		url :"http://localhost:8888/HrEvaluation/TechEvalById/"+data2 ,
		success: function(result)
		{
			console.log(result.obj.cadidateID);
			console.log(result.obj.cadidateName);
			$("#candidateId").html(result.obj.cadidateId)
			/*$("#candidateId").append(result.obj.cadidateId)*/
		    $("#candidateName").html(result.obj.candidateName)
		    $("#dateofApplication").html(result.obj.dateOfApplication)
			$("#canndidEmail").html(result.obj.candidateEmailId)
			$("#jobdescId").html(result.obj.jobDescId)
			$("#jobProfile").html(result.obj.jobProfile)
			$("#interviewerid").html(result.obj.interviewerId)
			$("#moi").html(result.obj.modeOfInterview)
			$("#expectedctc").html(result.obj.candidateExpectedCTC)
			$("#currentctc").html(result.obj.candidateCurrentCTC)
			$("#moa").html(result.obj.modeOfApplication)
			$("#Ccompany").html(result.obj.currentComapanyName)
			$("#exp").html(result.obj.sinceWoring)
			$("#qualification").html(result.obj.candidateLastDegree)
			$("#score").html(result.obj.candidateLastScore)
			$("#passYear").html(result.obj.candidatePassingYear)
			$("#certification").html(result.obj.cadidateCertification)
			$("#appliedBefore").html(result.obj.candidateAppliedBefore)
			$("#techstatus").html(result.obj.techEvalStatus)
			$("#techCmmt").html(result.obj.techEvalComments)
			$("#noticetime").html(result.obj.candidateNoticePeriod)
		
			
		}
		});
	
}





$( document ).ready(function() {
	ajaxGet();
	
	// DO GET
	function ajaxGet(){
		$.ajax({
			type : "GET",
			url :"http://localhost:8888/HrEvaluation/getEvalList",
			success: function(result){
				console.log("sucessful")
				if(result.errorMessage == "success"){
					console.log("sucessfulllll")
						$.each(result.obj, function(index, obj){
							console.log("IN FOR EACH")
							var jobdesc = '<tr>' +
												'<td>' + result.obj[index].cadidateId +  '</td>' +
												'<td>' + result.obj[index].jobProfile +  '</td>' +
												'<td>' + result.obj[index].candidateEmailId + '</td>' +
												'<td>' + result.obj[index].currentComapanyName + '</td>' +
												'<td>' + result.obj[index].techEvalStatus+'</td>' +
												'<td><a href="hr_evaluation_form_rc.html" class="btn btn-primary btn-sm active" role="button" onclick=getcandidId('+result.obj[index].cadidateId+') >EVALUATION FORM</a></td>'+
												'<td><a href="#" style="color: #2196F3;" title="View" data-toggle="modal" data-target="#myModal1" onclick=hrViewById('+result.obj[index].cadidateId+')  ><i class="material-icons">&#xE417;</i></a></td>'           
												 					+ '</tr>';
						  $('#example tbody').append(jobdesc)
						});
				}else{
					$("#getResultDiv").html("<strong>Error</strong>");
				}
			},
			error : function(e) {
				$("#getResultDiv").html("<strong>Error</strong>");
				console.log("ERROR: ", e);
			}
		});		
	}
})
function getcandidId(data1)
{
			console.log("in dada1")
			sessionStorage.setItem("id",data1);
			var a=sessionStorage.getItem("id");
							
			
}


