/*$(document).ready(function() {
	//display();
	// Do GET all Customers from Back-End with JQUERY AJAX
	$(function () {
		$.ajax({
			type : "GET",
			url : window.location + "productAPI/products",
			success: function(result){
				$.each(result, function(index, customer){
					
					var customerRow = '<tr>' +
										'<td>'+ customer.productId+  '</td>' +
										'<td>' + customer.productName+'</td>' +
										'<td>'  + customer.price +  '</td>' +
										'<td class="text-center">' +
							        	'<input type="hidden" value=' + customer.productId + '>' +
							        	'<a>' +
					          				'<span class="glyphicon glyphicon-remove"></span>' +
					        			'</a>' +
							        '</td>' +
										
									  '</tr>';
					
					$('#customerTable tbody').append(customerRow);
					
		        });
				
				$( "#customerTable tbody tr:odd" ).addClass("info");
				$( "#customerTable tbody tr:even" ).addClass("success");
			},
			error : function(e) {
				alert("ERROR: ", e);
				console.log("ERROR: ", e);
			}
		});	
	});
	*/
	
	
	
	
	
/*	// Do DELETE a Customer via JQUERY AJAX
	$(document).on("click","a",function() {
		
		var customerId = $(this).parent().find('input').val();
		var workingObject = $(this);
		
		$.ajax({
			type : "DELETE",
			url : window.location + "productAPI/product/" + customerId,
			success: function(resultMsg){
				$("#resultMsgDiv").html("<p style='background-color:#67597E; color:white; padding:20px 20px 20px 20px'>" +
											"Customer with Id=" + customerId + " is deleted successfully!"  +
										"</p>");
				
				workingObject.closest("tr").remove();
				
				// re-css for table
				$( "#customerTable tbody tr:odd" ).addClass("info");
				$( "#customerTable tbody tr:even" ).addClass("success");
			},
			error : function(e) {
				alert("ERROR: ", e);
				console.log("ERROR: ", e);
			}
		});
	});
})*/


/*function display(){
	console.log("display called")
	$.ajax({
		type : "GET",
		url : window.location + "productAPI/products",
		success: function(result){
			$.each(result, function(index, customer){
				
				var customerRow = '<tr>' +
									'<td>'+ customer.productId+  '</td>' +
									'<td>' + customer.productName+'</td>' +
									'<td>'  + customer.price +  '</td>' +
									'<td class="text-center">' +
						        	'<input type="hidden" value=' + customer.productId + '>' +
						        	'<a>' +
				          				'<span class="glyphicon glyphicon-remove"></span>' +
				        			'</a>' +
						        '</td>' +
									
								  '</tr>';
				
				$('#customerTable tbody').append(customerRow);
				
	        });
			
			$( "#customerTable tbody tr:odd" ).addClass("info");
			$( "#customerTable tbody tr:even" ).addClass("success");
		},
		error : function(e) {
			alert("ERROR: ", e);
			console.log("ERROR: ", e);
		}
	});	
}
*/



function addProduct(){
	var productId=$("#pid").val();
	var productName=$("#pname").val();
	var price=$("#price").val();
	console.log(productId+" "+productName+" "+price);

	var obj = {"productId": productId, "productName":productName, "price":price};

	console.log(obj);

	var objJson=JSON.stringify(obj);
                
                
	$.ajax({
		url : 'http://localhost:8888/productAPI/product',
		type : 'POST',
		data : objJson,
		contentType: "application/json",
		dataType: 'json',
		success : function(txt) {
			  var x= JSON.stringify(txt);
			/*  $.ajax({
					type : "GET",
					url : window.location + "productAPI/products",
					success: function(result){
						$.each(result, function(index, customer){
							
							var customerRow = '<tr>' +
												'<td>'+ customer.productId+  '</td>' +
												'<td>' + customer.productName+'</td>' +
												'<td>'  + customer.price +  '</td>' +
												'<td class="text-center">' +
									        	'<input type="hidden" value=' + customer.productId + '>' +
									        	'<a>' +
							          				'<span class="glyphicon glyphicon-remove"></span>' +
							        			'</a>' +
									        '</td>' +
												
											  '</tr>';
							
							$('#customerTable tbody').append(customerRow);
							
				        });
						
						$( "#customerTable tbody tr:odd" ).addClass("info");
						$( "#customerTable tbody tr:even" ).addClass("success");
					},
					error : function(e) {
						alert("ERROR: ", e);
						console.log("ERROR: ", e);
					}
				});	
*/
			console.log(x);

		}

		
	}
	);

}

