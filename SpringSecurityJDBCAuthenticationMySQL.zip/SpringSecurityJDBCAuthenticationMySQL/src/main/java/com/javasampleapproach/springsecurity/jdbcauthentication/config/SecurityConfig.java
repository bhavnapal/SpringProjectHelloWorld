package com.javasampleapproach.springsecurity.jdbcauthentication.config;

import javax.sql.DataSource;

import org.apache.catalina.Role;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
@EnableAutoConfiguration
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
	DataSource dataSource;
	
	@Autowired
	CustomSuccessHandler customSuccessHandler;

	@Autowired
	public void configAuthentication(AuthenticationManagerBuilder auth) throws Exception {
		auth.jdbcAuthentication().dataSource(dataSource)
				.usersByUsernameQuery("select users,pass,enabled from mindgate_users where users=?")
				.authoritiesByUsernameQuery("select users,role from users_roles where users=?");
	}
/*	
	@Autowired
	public void configureGlobalSecurity(AuthenticationManagerBuilder auth) throws Exception {
		auth.inMemoryAuthentication().withUser("tl").password("tl123").roles("TL");
		auth.inMemoryAuthentication().withUser("pm").password("pm123").roles("PM");
		auth.inMemoryAuthentication().withUser("hr").password("hr123").roles("HR");
	}*/

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.authorizeRequests()
				.antMatchers("/", "/login").permitAll()
				// .antMatchers("/tl").hasAnyAuthority("ROLE_TL")
				/*
				 * .antMatchers("/tl").hasRole("TL") .antMatchers("/hr").hasRole("HR")
				 */ /*
					 * .antMatchers("/", "/").access("hasRole('USER')")
					 * .antMatchers("/admin/**").access("hasRole('ADMIN')")
					 */
		
				.antMatchers("/tl").access("hasRole('TL')")
				.antMatchers("/hr").access("hasRole('HR')")
				.antMatchers("/pm").access("hasRole('PM')")
				.antMatchers("/interviwer").access("hasRole('Interviwer')")
				/*.anyRequest().authenticated().and().formLogin().loginPage("/login").permitAll().and().logout()
				.permitAll();
		//http.exceptionHandling().accessDeniedPage("/403");*/
				.and().formLogin().loginPage("/login").successHandler(customSuccessHandler)
			  	.usernameParameter("username").passwordParameter("password")
			  	.and().csrf().and()
			  	.logout()
                .invalidateHttpSession(true)
                .clearAuthentication(true)
                .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
                .logoutSuccessUrl("/logout")
                .logoutUrl("/j_spring_security_logout")
                .permitAll()
			  	.and().exceptionHandling().accessDeniedPage("/403");
			
				
	}
}