package com.javasampleapproach.springsecurity.jdbcauthentication.controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
 
@EnableGlobalMethodSecurity
@Controller
public class WebController {
   
    @RequestMapping(value="/")
    public String home(){
        return "login";
    }
   
  //  @PreAuthorize("hasAnyAuthority('ROLE_HR')")
    @RequestMapping(value="/tl")
    public String tl(){
        return "job_description_list_tl";
    }
    
  //  @PreAuthorize("hasAnyAuthority('ROLE_TL')")
    @RequestMapping(value="/pm")
    public String pm(){
        return "job_description_list_pm";
    }
  
 //   @PreAuthorize("hasAnyAuthority('ROLE_PM')")
    @RequestMapping(value="/hr")
    public String hr(){
        return "hr_evaluation_list_rc";
    }
    
    @RequestMapping(value="/interviewer")
    public String interviewer(){
        return "technical_evaluation_list";
    }

   
    @RequestMapping(value="/login")
    public String login(){
        return "login";
    }
     
    @RequestMapping(value="/403")
    public String Error403(){
        return "403";
    }
}
